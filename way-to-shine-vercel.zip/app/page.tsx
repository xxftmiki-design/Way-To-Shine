use client";

import { useEffect, useMemo, useState } from "react";

type Group = "EDN48" | "TLP48";
type Member = { name: string; realName: string; age: number; ig: string; color: string };

const members: Record<Group, Member[]> = {
  EDN48: [
    { name: "Iris", realName: "Iris Example", age: 20, ig: "@edn48_iris", color: "#c9b2ff" },
    { name: "Mimi", realName: "Mimi Example", age: 19, ig: "@edn48_mimi", color: "#c9b2ff" },
    { name: "Aira", realName: "Aira Example", age: 21, ig: "@edn48_aira", color: "#c9b2ff" },
    { name: "Sirin", realName: "Sirin Example", age: 18, ig: "@edn48_sirin", color: "#c9b2ff" }
  ],
  TLP48: [
    { name: "Luna", realName: "Luna Example", age: 20, ig: "@tlp48_luna", color: "#9fddff" },
    { name: "Mew", realName: "Mew Example", age: 19, ig: "@tlp48_mew", color: "#9fddff" },
    { name: "Pearl", realName: "Pearl Example", age: 21, ig: "@tlp48_pearl", color: "#9fddff" },
    { name: "Nana", realName: "Nana Example", age: 18, ig: "@tlp48_nana", color: "#9fddff" }
  ]
};

const events: Record<Group, { date: string; title: string; place: string }[]> = {
  EDN48: [
    { date: "03 OCT", title: "EDN48 THE 1ST STAGE", place: "EDEN CLUB" },
    { date: "10 OCT", title: "MEET & GREET", place: "BANGKOK" },
    { date: "18 OCT", title: "SPARK LIVE", place: "EDEN HALL" }
  ],
  TLP48: [
    { date: "05 OCT", title: "TLP48 THE 1ST STAGE", place: "TULIP ZONE" },
    { date: "12 OCT", title: "TULIP MEET & GREET", place: "BANGKOK" },
    { date: "24 OCT", title: "TLP48 SPECIAL LIVE", place: "TULIP HALL" }
  ]
};

const spark = [
  { group: "EDN48" as Group, member: "Iris", votes: 12480 },
  { group: "TLP48" as Group, member: "Luna", votes: 11620 },
  { group: "EDN48" as Group, member: "Mimi", votes: 9850 },
  { group: "TLP48" as Group, member: "Pearl", votes: 9320 }
];

function Icon({ children }: { children: React.ReactNode }) {
  return <span className="icon" aria-hidden>{children}</span>;
}

export default function Home() {
  const [screen, setScreen] = useState<"welcome" | "home" | "members" | "club" | "account" | "music" | "vote">("welcome");
  const [group, setGroup] = useState<Group>("EDN48");
  const [loggedIn, setLoggedIn] = useState(false);
  const [loginOpen, setLoginOpen] = useState(false);
  const [email, setEmail] = useState("");
  const [token, setToken] = useState(1200);
  const [star, setStar] = useState(80);
  const [oshi, setOshi] = useState<string[]>([]);
  const [kami, setKami] = useState<string | null>(null);
  const [toast, setToast] = useState("");

  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem("wts-data") || "{}");
      if (saved.token != null) setToken(saved.token);
      if (saved.star != null) setStar(saved.star);
      if (Array.isArray(saved.oshi)) setOshi(saved.oshi);
      if (saved.kami) setKami(saved.kami);
      if (saved.loggedIn) setLoggedIn(true);
    } catch {}
  }, []);

  useEffect(() => {
    localStorage.setItem("wts-data", JSON.stringify({ token, star, oshi, kami, loggedIn }));
  }, [token, star, oshi, kami, loggedIn]);

  const themeClass = group === "EDN48" ? "eden" : "tlp";
  const currentMembers = members[group];
  const currentEvents = events[group];
  const currentSpark = useMemo(() => spark.filter((x) => x.group === group), [group]);

  function notify(message: string) {
    setToast(message);
    window.setTimeout(() => setToast(""), 2200);
  }

  function chooseGroup(g: Group) {
    setGroup(g);
    setScreen("home");
  }

  function toggleOshi(name: string) {
    setOshi((old) => old.includes(name) ? old.filter((x) => x !== name) : [...old, name]);
    notify(oshi.includes(name) ? `นำ ${name} ออกจาก Oshi แล้ว` : `เพิ่ม ${name} เป็น Oshi แล้ว`);
  }

  function buyVote() {
    if (star < 10) return notify("STAR ไม่พอ");
    setStar((x) => x - 10);
    notify("ใช้ 10 STAR เพื่อโหวต SPARK OF THE MONTH แล้ว");
  }

  return (
    <main className={`app ${themeClass}`}>
      <div className="ambient one" />
      <div className="ambient two" />

      {screen === "welcome" ? (
        <section className="welcome">
          <div className="brand-mark">W</div>
          <p className="eyebrow">APPLICATION</p>
          <h1>WAY TO <span>SHINE</span></h1>
          <p className="sub">Your stage. Your star. Your way to shine.</p>

          <div className="group-carousel" aria-label="เลือกวง">
            <button className="group-card small" onClick={() => chooseGroup("TLP48")}>
              <b>TLP48</b><span>TULIP ZONE</span>
            </button>
            <button className="group-card active" onClick={() => chooseGroup("EDN48")}>
              <b>EDN48</b><span>EDEN CLUB</span></button>
            <button className="group-card small" onClick={() => chooseGroup("TLP48")}>
              <b>TLP48</b><span>TULIP ZONE</span>
            </button>
          </div>

          <button className="artist-button" onClick={() => notify("WAY TO SHINE ARTIST — กำลังเตรียมข้อมูล")}>
            WAY TO SHINE <strong>ARTIST</strong><span>→</span>
          </button>
          <div className="swipe-hint">ปัดซ้าย / ขวา เพื่อเลือกวง • แตะการ์ดเพื่อเข้าใช้งาน</div>
        </section>
      ) : (
        <>
          <header className="topbar">
            <button className="logo" onClick={() => setScreen("welcome")}>WTS</button>
            <div className="top-title">
              <span>WAY TO SHINE</span>
              <strong>{group}</strong>
            </div>
            <button className="account-mini" onClick={() => setScreen("account")}>
              <Icon>◉</Icon>
              <span>{loggedIn ? "ACCOUNT" : "LOGIN"}</span>
            </button>
          </header>

          <div className="group-switch">
            <button className={group === "EDN48" ? "selected" : ""} onClick={() => setGroup("EDN48")}>EDN48</button>
            <button className={group === "TLP48" ? "selected" : ""} onClick={() => setGroup("TLP48")}>TLP48</button>
          </div>

          {screen === "home" && (
            <div className="page">
              <section className="hero">
                <div>
                  <span className="pill">OFFICIAL APPLICATION</span>
                  <h2>{group === "EDN48" ? "WELCOME TO EDEN" : "WELCOME TO TULIP"}</h2>
                  <p>{group === "EDN48" ? "A place where every dream can shine." : "Together, we bloom and shine."}</p>
                </div>
                <div className="hero-badge">{group}<br/><small>WAY TO SHINE</small></div>
              </section>

              <section className="section">
                <div className="section-head"><div><span className="eyebrow">UPCOMING</span><h3>SCHEDULE</h3></div><button onClick={() => notify("เปิดตารางงานทั้งหมด")}>VIEW ALL →</button></div>
                <div className="event-grid">
                  {currentEvents.map((e) => <article className="event-card" key={e.title}><b>{e.date}</b><div><h4>{e.title}</h4><p>{e.place}</p></div></article>)}
                </div>
              </section>

              <section className="section">
                <div className="section-head"><div><span className="eyebrow">MONTHLY PROJECT</span><h3>SPARK OF THE MONTH</h3></div><button onClick={() => setScreen("vote")}>VOTE →</button></div>
                <div className="spark-list">
                  {currentSpark.map((s, i) => <div className="spark-row" key={s.member}><span className="rank">{i + 1}</span><span className="spark-avatar">{s.member[0]}</span><div><b>{s.member}</b><small>{s.group}</small></div><strong>{s.votes.toLocaleString()} <small>VOTES</small></strong></div>)}
                </div>
              </section>

              <section className="section single-work">
                <span className="eyebrow">LATEST WORK</span>
                <h3>{group} 1ST SINGLE</h3>
                <p>ผลงานล่าสุดของวง พร้อมข้อมูลเพลงและกิจกรรมโปรโมต</p>
                <button className="primary" onClick={() => setScreen("music")}>MUSIC AUDIO →</button>
              </section>
            </div>
          )}

          {screen === "members" && (
            <div className="page">
              <section className="section page-title"><span className="eyebrow">THE MEMBERS</span><h2>{group}</h2><p>สมาชิก • อายุ • ชื่อจริง • Instagram</p></section>
              <div className="member-grid">
                {currentMembers.map((m) => <article className="member-card" key={m.name}><div className="member-photo" style={{background: `radial-gradient(circle at 50% 30%, ${m.color}, transparent 55%)`}}><span>{m.name[0]}</span></div><div className="member-info"><h3>{m.name}</h3><p>{m.realName}</p><div className="member-meta"><span>{m.age} YEARS</span><span>{m.ig}</span></div><div className="member-actions"><button onClick={() => toggleOshi(m.name)}>{oshi.includes(m.name) ? "★ OSHI" : "☆ OSHI"}</button><button onClick={() => {setKami(m.name); notify(`${m.name} เป็น Kami Oshi แล้ว`)}}>KAMI OSHI</button></div></div></article>)}
              </div>
              <section className="social-box"><h3>INFORMATION / SOCIAL MEDIA</h3><p>Official Website • Instagram • X • YouTube • TikTok • Facebook</p></section>
            </div>
          )}

          {screen === "club" && (
            <div className="page">
              <section className="club-hero"><span className="eyebrow">{group === "EDN48" ? "EDN48 MEMBERSHIP" : "TLP48 MEMBERSHIP"}</span><h2>{group === "EDN48" ? "EDEN CLUB" : "TULIP ZONE"}</h2><p>พื้นที่พิเศษสำหรับแฟน ๆ ของ {group}</p></section>
              <div className="menu-grid">
                <button className="menu-card" onClick={() => notify("เปิดหน้า Redeem Code")}><Icon>⌁</Icon><b>REDEEM CODE</b><small>แลกรหัสสิทธิพิเศษ</small></button>
                <button className="menu-card" onClick={() => setScreen("vote")}><Icon>★</Icon><b>MAJOR VOTE</b><small>ใช้ STAR เพื่อสนับสนุนสมาชิก</small></button>
                <button className="menu-card" onClick={() => notify("TOKEN SHOP พร้อมใช้งาน")}><Icon>◇</Icon><b>TOKEN SHOP</b><small>ซื้อของและไอเทมต่าง ๆ</small></button>
                <button className="menu-card" onClick={() => notify("สิทธิพิเศษสมาชิกกำลังอัปเดต")}><Icon>✦</Icon><b>MEMBERSHIP</b><small>สิทธิพิเศษของสมาชิก</small></button>
              </div>
              <div className="wallet-row"><div><small>STAR</small><b>★ {star}</b></div><div><small>TOKEN</small><b>◇ {token.toLocaleString()}</b></div></div>
            </div>
          )}

          {screen === "vote" && (
            <div className="page">
              <section className="section page-title"><span className="eyebrow">MONTHLY RANKING</span><h2>SPARK OF THE MONTH</h2><p>เลือกสมาชิกของ {group} และใช้ STAR เพื่อโหวต</p></section>
              <div className="vote-grid">{currentMembers.map((m, i) => <article className="vote-card" key={m.name}><span className="rank-big">0{i+1}</span><div className="vote-avatar">{m.name[0]}</div><h3>{m.name}</h3><p>{currentSpark[i % currentSpark.length]?.votes.toLocaleString()} votes</p><button className="primary" onClick={buyVote}>★ VOTE 10 STAR</button></article>)}</div>
            </div>
          )}

          {screen === "music" && (
            <div className="page">
              <section className="section page-title"><span className="eyebrow">MUSIC</span><h2>{group} 1ST SINGLE</h2><p>จบ • END</p></section>
              <div className="music-card"><div className="record">♪</div><div><span className="eyebrow">NOW PLAYING</span><h3>{group} — 1st Single</h3><p>Audio player พร้อมเชื่อมไฟล์เพลงจริงภายหลัง</p></div><button onClick={() => notify("ยังไม่ได้อัปโหลดไฟล์เสียง")}>▶</button></div>
              <div className="track"><span>01</span><b>1st SINGLE — END</b><small>03:45</small></div>
            </div>
          )}

          {screen === "account" && (
            <div className="page">
              <section className="account-head"><div className="profile">W</div><div><span className="eyebrow">MY ACCOUNT</span><h2>{loggedIn ? (email || "SHINE USER") : "GUEST"}</h2><p>{loggedIn ? "บัญชีของคุณพร้อมใช้งาน" : "เข้าสู่ระบบเพื่อบันทึกข้อมูลของคุณ"}</p></div>{!loggedIn && <button className="primary" onClick={() => setLoginOpen(true)}>LOGIN</button>}</section>
              <div className="stats"><div><small>OSHI</small><b>{oshi.length}</b><span>คน</span></div><div><small>KAMI OSHI</small><b>{kami || "—"}</b><span>สมาชิก</span></div><div><small>TOKEN</small><b>{token.toLocaleString()}</b><span>เหรียญ</span></div><div><small>STAR</small><b>★ {star}</b><span>คะแนนโหวต</span></div></div>
              <section className="section"><div className="section-head"><div><span className="eyebrow">YOUR OSHI</span><h3>OSHI LIST</h3></div></div>{oshi.length ? <div className="oshi-list">{oshi.map((x) => <span key={x}>★ {x}</span>)}</div> : <div className="empty">ยังไม่มี Oshi — ไปที่ Members เพื่อเลือกสมาชิก</div>}</section>
              {loggedIn && <button className="outline" onClick={() => {setLoggedIn(false); setEmail(""); notify("ออกจากระบบแล้ว")}}>LOG OUT</button>}
            </div>
          )}

          <nav className="bottom-nav">
            <button className={screen === "home" ? "on" : ""} onClick={() => setScreen("home")}><Icon>⌂</Icon><span>HOME</span></button>
            <button className={screen === "members" ? "on" : ""} onClick={() => setScreen("members")}><Icon>♙</Icon><span>MEMBERS</span></button>
            <button className={screen === "club" ? "on" : ""} onClick={() => setScreen("club")}><Icon>✦</Icon><span>{group === "EDN48" ? "EDEN CLUB" : "TULIP ZONE"}</span></button>
            <button className={screen === "music" ? "on" : ""} onClick={() => setScreen("music")}><Icon>♫</Icon><span>MUSIC</span></button>
            <button className={screen === "account" ? "on" : ""} onClick={() => setScreen("account")}><Icon>◉</Icon><span>ACCOUNT</span></button>
          </nav>
        </>
      )}

      {loginOpen && (
        <div className="modal-backdrop" onClick={() => setLoginOpen(false)}>
          <div className="login-card" onClick={(e) => e.stopPropagation()}>
            <button className="close" onClick={() => setLoginOpen(false)}>×</button>
            <span className="eyebrow">WAY TO SHINE</span>
            <h2>LOGIN</h2>
            <p>เข้าสู่ระบบเพื่อบันทึก Oshi, Kami Oshi, STAR และ TOKEN ของคุณ</p>
            <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email / Username" />
            <input type="password" placeholder="Password" />
            <button className="primary full" onClick={() => {setLoggedIn(true); setLoginOpen(false); notify("เข้าสู่ระบบสำเร็จ")}}>LOGIN</button>
            <button className="ghost" onClick={() => notify("ระบบสมัครสมาชิกกำลังเตรียมเปิด")}>CREATE ACCOUNT</button>
            <small className="security-note">เดโมนี้เก็บข้อมูลในเครื่องด้วย localStorage เท่านั้น หากใช้งานจริงควรเชื่อมระบบ Auth/Database ฝั่งเซิร์ฟเวอร์</small>
          </div>
        </div>
      )}

      {toast && <div className="toast">{toast}</div>}
    </main>
  );
}