import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "WAY TO SHINE",
  description: "Official fan application for EDN48 & TLP48",
  themeColor: "#070a12"
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="th">
      <body>{children}</body>
    </html>
  );
}