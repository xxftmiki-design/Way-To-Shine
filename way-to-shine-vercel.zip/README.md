# WAY TO SHINE

Next.js app for EDN48 & TLP48.

## Run locally
```bash
npm install
npm run dev
```
Open http://localhost:3000

## Deploy to Vercel
1. Upload this folder to a GitHub repository.
2. In Vercel, choose **Add New Project** and import the repository.
3. Framework preset: Next.js.
4. Build command: `npm run build`
5. Deploy.

## Included
- Welcome screen + EDN48/TLP48 selector
- Responsive carousel-style selector
- Group-specific Home / Schedule / Latest Work
- SPARK OF THE MONTH + voting UI
- Members / age / real name / Instagram UI
- EDEN CLUB / TULIP ZONE
- Redeem Code / Major Vote / Token Shop UI
- Account / Oshi / Kami Oshi / STAR / TOKEN
- Login UI
- EDN48 purple-pastel and TLP48 blue-white themes
- Supplied gradient images included in `public/eden-bg.png` and `public/tlp-bg.png`
- Local persistence via localStorage for the demo

## Production note
The login and wallet in this starter are demo-only. For real accounts, STAR/TOKEN balances, payments, votes, redeem codes, and admin updates, connect a real authentication/database backend such as Supabase and validate all sensitive actions server-side.
